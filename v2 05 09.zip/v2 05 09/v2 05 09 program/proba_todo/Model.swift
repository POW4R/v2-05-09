import Foundation
// Creating a struct to represent a Todo item
// It is the model of the app and conforms to Identifiable and Codable protocols
struct TodoItem: Identifiable, Codable {
    var id = UUID()
    var title: String
    var point: Int
    var isComplete = false
    var createdAt = Date()
}
