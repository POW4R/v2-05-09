//
//  proba_todoApp.swift
//  proba_todo
//
//  Created by 4-11-5-hallgato on 18/04/2024.
//

import SwiftUI

@main
struct proba_todoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
