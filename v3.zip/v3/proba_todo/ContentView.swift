// Import SwiftUI framework to create UI elements
import SwiftUI
// Creating a struct to represent the UI of the app
struct ContentView: View {
    // Creating a property to store the new Todo item
    @State private var newTodoItem = ""
    var points = [1,2,3,4,5,6]
    @State private var selectedPoint = 1
    @StateObject private var viewModel = TodoListViewModel()
    @StateObject var model = Client()
    // Creating UI elements to represent the UI of the app
    var body: some View {
        // Creating a vertical stack to hold the UI elements
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack {
                // Creating a text view to display the title of the app
                
                Text("EcoTasks")
                    .font(.largeTitle)
                    .padding()
                
                AsyncImage(url: URL(string: "https://openweathermap.org/img/wn/\(model.current.current?.weather?[0].icon ?? "")@2x.png"))
                Text(model.current.current?.weather?[0].description ?? "")
                Text(String(format: "%.0f C",model.current.current?.temp ?? 0))
                    .font(.title3)
                
                
                // Creating a list to display the list of Todo items
                List {
                    
                    // Creating a for each loop to iterate over the list of Todo items
                    ForEach(viewModel.todoItems) { item in
                        // Creating a horizontal stack to hold the UI elements
                        HStack {
                            
                            // Creating a text view to display the title of the Todo item
                            Text(item.title)
                                .strikethrough(item.isComplete)
                                .foregroundColor(item.isComplete ? .gray : .primary)
                            Spacer()
                            Text(dateFormatter(date:item.createdAt))
                                .font(.footnote)
                            
                            Picker("Point:", selection: $selectedPoint) {
                                Text("1").tag(0)
                                Text("2").tag(1)
                                Text("3").tag(2)
                            }
                        }
                    
                    // Creating a button to toggle the completion status of the Todo item
                    Button(action: {
                        viewModel.toggleTodoItemCompletion(item)
                    }) {
                        Image(systemName: item.isComplete ? "checkmark.circle" : "circle")
                            .foregroundColor(item.isComplete ? Color.green : Color.red)
                        
                    }
                    
                }
                //.background(Color.white.opacity(0.5))
                .listRowBackground(Color.white.opacity(0.5))
                
            }
            
            
            
            // Creating a horizontal stack to hold the UI elements to add a new Todo item
            HStack {
                // Creating a text field to enter the title of the new Todo item
                TextField("Enter new EcoTask item", text: $newTodoItem)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                // Creating a button to add the new Todo item
                Button(action: {
                    viewModel.addTodoItem(title: newTodoItem)
                    newTodoItem = ""
                }) {
                    Text("Add")
                }
                .padding()
            }
            .background(Color.white.opacity(0.5))
            .padding(4)
        }
        .environment(\.locale, Locale(identifier: "hu"))
        .cornerRadius(10)
        .scrollContentBackground(.hidden)
        //.background(.red)
        
        
    }
        .task {
            do {
                let data = try await Client().getCurrentWeather()
                print(data.current?.temp ?? 0)
                self.model.current = data
            } catch {
                print(error.localizedDescription)
            }
        }
}
}
func dateFormatter(date: Date) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd hh:mm"
    dateFormatter.locale = Locale(identifier: "hu_HU")
    let d = dateFormatter.string(from: date)
    print(d)
    return d
}

// Creating a struct to represent the preview of the app
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#Preview {
    ContentView()
}
