
import Foundation

class Client: ObservableObject {
    @Published var current = CurrentWeatherResponse()
    
    enum NetworkError: Error {
        case invalidURL
        case requestFailed(String)
    }
    
    func getCurrentWeather() async throws -> CurrentWeatherResponse  {
        guard let url = URL(string: "https://api.openweathermap.org/data/3.0/onecall?lat=46.900&lon=19.783&&units=metric&&lang=hu&appid=b4dd24db622e97675c1a7c706e137c90") else {
            throw NetworkError.invalidURL
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw NetworkError.requestFailed("Invalid response")
        }
        
        return try JSONDecoder().decode(CurrentWeatherResponse.self, from: data)
    }
}
